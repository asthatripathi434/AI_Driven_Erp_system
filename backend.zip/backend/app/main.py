from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import jwt

# Import routers
from app.api import auth, students, fees, reports, results, timetable, dressfees, payments, webhook
from app.core.config import settings



# -----------------------------
# FastAPI app setup
# -----------------------------
app = FastAPI(
    title=f"{settings.SCHOOL_NAME} ERP - {settings.SCHOOL_PLACE}",
    version="1.0.0",
    description="School ERP backend for authentication, students, fees, results, timetable, and dress fees."
)

# -----------------------------
# CORS for local frontend
# -----------------------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],  # React dev server
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# -----------------------------
# Security scheme (JWT)
# -----------------------------
security = HTTPBearer()

def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        payload = jwt.decode(
            credentials.credentials,
            settings.SECRET_KEY,
            algorithms=[settings.ALGORITHM]
        )
        return payload
    except jwt.PyJWTError:
        raise HTTPException(status_code=401, detail="Invalid or expired token")

# -----------------------------
# Register routers
# -----------------------------
# Public routes (no JWT required)
app.include_router(auth.router)          # login/signup
app.include_router(webhook.router)       # Razorpay webhook (must be public)

# Protected routes (JWT required)


app.include_router(students.router, dependencies=[Depends(verify_token)])
app.include_router(fees.router, dependencies=[Depends(verify_token)])
app.include_router(reports.router, dependencies=[Depends(verify_token)])
app.include_router(results.router, dependencies=[Depends(verify_token)])
app.include_router(timetable.router, dependencies=[Depends(verify_token)])
app.include_router(dressfees.router, dependencies=[Depends(verify_token)])
app.include_router(payments.router, dependencies=[Depends(verify_token)])  # payment link/order creation

# -----------------------------
# Root endpoint
# -----------------------------
@app.get("/")
def root():
    return {"status": "ok"}